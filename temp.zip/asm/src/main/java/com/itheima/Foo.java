package com.itheima;

public interface Foo {

    public void foo();

}
