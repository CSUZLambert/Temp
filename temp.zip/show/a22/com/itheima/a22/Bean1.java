package com.itheima.a22;

public interface Bean1 {
    public void foo(String name, int age);
}
