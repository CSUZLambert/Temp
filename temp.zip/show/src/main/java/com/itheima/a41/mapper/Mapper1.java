package com.itheima.a41.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface Mapper1 {
}
