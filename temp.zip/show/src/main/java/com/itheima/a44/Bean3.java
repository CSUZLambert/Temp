package com.itheima.a44;

import org.springframework.stereotype.Component;

@Component
public class Bean3 {
}
