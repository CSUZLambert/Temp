package com.itheima.a23.sub;

class StudentDao extends BaseDao<Student> {
}
