package com.itheima.a23.sub;

class TeacherDao extends BaseDao<Teacher> {
}
