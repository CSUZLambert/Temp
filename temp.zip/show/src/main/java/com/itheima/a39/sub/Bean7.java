package com.itheima.a39.sub;

import org.springframework.stereotype.Component;

@Component
public class Bean7 {
}
