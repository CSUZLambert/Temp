package com.itheima.a05.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface Mapper1 {
}
