package com.itheima.a45;

import org.springframework.stereotype.Component;

@Component
public class Bean2 {
}
