package com.itheima.a21;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {
}
